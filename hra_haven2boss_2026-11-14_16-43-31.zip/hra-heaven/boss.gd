extends CharacterBody2D

@export var health: int = 220
@export var rychlost: float = 105.0
@export var dosah_viditelnosti: float = 520.0
@export var poskozeni_utoku: int = 16

var _target: CharacterBody2D
var _attack_cooldown: float = 0.0

func _ready() -> void:
	add_to_group("enemies")
	collision_layer = 4
	collision_mask = 1
	_target = get_tree().get_first_node_in_group("player") as CharacterBody2D

func _physics_process(delta: float) -> void:
	_attack_cooldown = maxf(0.0, _attack_cooldown - delta)
	if not is_on_floor():
		velocity.y += get_gravity().y * delta
	if _target and is_instance_valid(_target) and not _target.get("is_dead") == true:
		var offset := _target.global_position - global_position
		if offset.length() <= dosah_viditelnosti and absf(offset.y) < 140.0:
			velocity.x = signf(offset.x) * rychlost if absf(offset.x) > 42.0 else 0.0
			if offset.length() < 54.0 and _attack_cooldown <= 0.0:
				_target.call("take_damage", poskozeni_utoku, Vector2(signf(offset.x) * 180.0, -90.0))
				_attack_cooldown = 1.2
		else:
			velocity.x = move_toward(velocity.x, 0.0, 500.0 * delta)
	move_and_slide()

func take_damage(amount: int, knockback: Vector2 = Vector2.ZERO) -> void:
	health -= amount
	velocity += knockback
	if health <= 0:
		queue_free()
