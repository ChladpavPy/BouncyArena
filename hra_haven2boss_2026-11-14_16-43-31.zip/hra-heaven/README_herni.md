# Heaven: Proti proudu času

Temná 2D plošinovka. Hráč prochází sedmi epochami od roku 2420 až k první osadě v roce 500 a na konci bojuje se Strážcem času.

## Ovládání

- **A / D** nebo **← / →**: pohyb
- **Mezerník / ↑**: skok; ve vzduchu lze skočit ještě jednou
- **Shift**: běh
- **J**: úder zblízka
- **K**: časový pulz, který zasáhne nepřátele v okolí (obnova po 5 sekundách)
- **Esc**: pauza

Časové krystaly obnovují zdraví. Světle zelené praporky jsou kontrolní body. Pád do propasti nebo porážka hráče jej vrátí na poslední bod. Boss mění chování po ztrátě poloviny zdraví.
