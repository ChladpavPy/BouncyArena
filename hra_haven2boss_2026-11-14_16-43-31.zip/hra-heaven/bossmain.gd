extends CharacterBody2D

signal health_changed(current: int, maximum: int)
signal defeated

const PROJECTILE_SCENE: PackedScene = preload("res://scenes/boss_projectile.tscn")

@export var max_health: int = 360
@export var move_speed: float = 92.0
@export var melee_damage: int = 22
@export var projectile_damage: int = 16

var health: int = 360
var _target: CharacterBody2D
var _attack_cooldown: float = 1.2
var _attacking: bool = false
var _defeated: bool = false
var _facing: int = -1

@onready var animated_sprite: AnimatedSprite2D = $AnimatedSprite2D

func _ready() -> void:
	add_to_group("enemies")
	add_to_group("final_boss")
	collision_layer = 4
	collision_mask = 1
	health = max_health
	var collider := get_node_or_null("CollisionShape2D") as CollisionShape2D
	if collider:
		collider.disabled = false
	_target = get_tree().get_first_node_in_group("player") as CharacterBody2D
	if animated_sprite.sprite_frames and animated_sprite.sprite_frames.has_animation("idle1"):
		animated_sprite.play("idle1")
	health_changed.emit(health, max_health)

func _physics_process(delta: float) -> void:
	if _defeated:
		return
	_attack_cooldown = maxf(0.0, _attack_cooldown - delta)
	if not is_on_floor():
		velocity.y += get_gravity().y * delta
	if not _target or not is_instance_valid(_target) or _target.get("is_dead") == true:
		velocity.x = move_toward(velocity.x, 0.0, 500.0 * delta)
		move_and_slide()
		return
	var offset := _target.global_position - global_position
	_facing = 1 if offset.x >= 0.0 else -1
	if absf(offset.x) < 1000.0 and absf(offset.y) < 180.0:
		if absf(offset.x) > 78.0:
			velocity.x = move_toward(velocity.x, _facing * _current_speed(), 520.0 * delta)
		else:
			velocity.x = move_toward(velocity.x, 0.0, 900.0 * delta)
		if _attack_cooldown <= 0.0 and not _attacking:
			_attack(offset)
	else:
		velocity.x = move_toward(velocity.x, 0.0, 500.0 * delta)
	move_and_slide()

func _current_speed() -> float:
	return move_speed * (1.4 if health <= max_health / 2 else 1.0)

func _attack(offset: Vector2) -> void:
	_attacking = true
	_attack_cooldown = 1.65 if health > max_health / 2 else 1.05
	if animated_sprite.sprite_frames and animated_sprite.sprite_frames.has_animation("fire"):
		animated_sprite.play("fire")
	animated_sprite.modulate = Color("#ff9b70")
	await get_tree().create_timer(0.3).timeout
	if not is_inside_tree() or _defeated:
		return
	animated_sprite.modulate = Color.WHITE
	if absf(offset.x) < 155.0 and absf(offset.y) < 110.0:
		_target.call("take_damage", melee_damage if health > max_health / 2 else melee_damage + 6, Vector2(_facing * 330.0, -180.0))
	elif absf(offset.x) < 720.0:
		var projectile := PROJECTILE_SCENE.instantiate() as Area2D
		get_tree().current_scene.add_child(projectile)
		projectile.global_position = global_position + Vector2(_facing * 44.0, -15.0)
		projectile.call("launch", Vector2(_facing, -0.08), projectile_damage if health > max_health / 2 else projectile_damage + 5)
	if animated_sprite.sprite_frames and animated_sprite.sprite_frames.has_animation("idle1"):
		animated_sprite.play("idle1")
	_attacking = false

func take_damage(amount: int, knockback: Vector2 = Vector2.ZERO) -> void:
	if _defeated:
		return
	health = maxi(0, health - amount)
	velocity += knockback
	animated_sprite.modulate = Color("#9ceaff")
	get_tree().create_timer(0.12).timeout.connect(func():
		if is_instance_valid(animated_sprite) and not _defeated:
			animated_sprite.modulate = Color.WHITE
	)
	health_changed.emit(health, max_health)
	if health <= 0:
		_defeated = true
		defeated.emit()
		queue_free()
