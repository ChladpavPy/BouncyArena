extends Node2D

const MAP_WIDTH := 5600.0
const MAP_BOTTOM := 980.0
const SECTION_WIDTH := 800.0

const ERAS := [
	{"name": "ROK 2420  |  MĚSTO PO PÁDU", "color": Color("#193949"), "accent": Color("#49e4d1")},
	{"name": "ROK 2200  |  OPUŠTĚNÁ TOVÁRNA", "color": Color("#273348"), "accent": Color("#e6a64c")},
	{"name": "ROK 2000  |  ZAMRZLÉ PŘEDMĚSTÍ", "color": Color("#24364b"), "accent": Color("#79b8e8")},
	{"name": "ROK 1800  |  STARÉ MĚSTO", "color": Color("#403341"), "accent": Color("#df8d58")},
	{"name": "ROK 1500  |  ZAPOMENUTÁ VESNICE", "color": Color("#354032"), "accent": Color("#a4bd67")},
	{"name": "ROK 1000  |  TEMNÝ LES", "color": Color("#28352e"), "accent": Color("#bd755e")},
	{"name": "ROK 500  |  PRVNÍ OSADA", "color": Color("#3e302b"), "accent": Color("#d0a05d")}
]

func _ready() -> void:
	_build_backdrop()
	_build_route()
	_build_landmarks()
	_place_existing_characters()

func _build_backdrop() -> void:
	var background := ColorRect.new()
	background.color = Color("#080b16")
	background.position = Vector2(-300, -300)
	background.size = Vector2(MAP_WIDTH + 600, MAP_BOTTOM + 700)
	background.z_index = -100
	add_child(background)
	for i in range(120):
		var star := Polygon2D.new()
		var px := float((i * 379 + 83) % int(MAP_WIDTH))
		var py := float((i * 211 + 37) % 850)
		var r := 1.0 + float(i % 3)
		star.polygon = PackedVector2Array([Vector2(-r, -r), Vector2(r, -r), Vector2(r, r), Vector2(-r, r)])
		star.position = Vector2(px, py)
		star.color = Color(0.38, 0.56, 0.70, 0.25 + float(i % 5) * 0.08)
		star.z_index = -80
		add_child(star)
	for i in range(7):
		var band := Polygon2D.new()
		var x := float(i) * SECTION_WIDTH
		var tint: Color = ERAS[i]["color"]
		band.polygon = PackedVector2Array([Vector2.ZERO, Vector2(SECTION_WIDTH, 0), Vector2(SECTION_WIDTH, MAP_BOTTOM), Vector2(0, MAP_BOTTOM)])
		band.position = Vector2(x, 0)
		band.color = Color(tint.r, tint.g, tint.b, 0.20)
		band.z_index = -70
		add_child(band)
		var title := Label.new()
		title.text = String(ERAS[i]["name"])
		title.position = Vector2(x + 55, 70)
		title.add_theme_font_size_override("font_size", 22)
		title.add_theme_color_override("font_color", ERAS[i]["accent"])
		title.add_theme_color_override("font_shadow_color", Color(0, 0, 0, 0.85))
		title.add_theme_constant_override("shadow_offset_x", 2)
		title.add_theme_constant_override("shadow_offset_y", 2)
		title.z_index = -20
		add_child(title)
		var divider := Polygon2D.new()
		divider.polygon = PackedVector2Array([Vector2.ZERO, Vector2(3, 0), Vector2(3, 740), Vector2(0, 740)])
		divider.position = Vector2(x, 170)
		divider.color = Color(ERAS[i]["accent"].r, ERAS[i]["accent"].g, ERAS[i]["accent"].b, 0.28)
		divider.z_index = -30
		add_child(divider)

func _build_route() -> void:
	# Souvislá cesta se střídá s krátkými skoky, schody a vyvýšenými plošinami.
	var platforms: Array[Rect2] = [
		Rect2(0, 500, 500, 90), Rect2(570, 450, 210, 34), Rect2(830, 510, 360, 90),
		Rect2(1220, 460, 220, 34), Rect2(1490, 530, 340, 90), Rect2(1870, 470, 190, 34),
		Rect2(2100, 520, 480, 90), Rect2(2630, 450, 240, 34), Rect2(2920, 510, 390, 90),
		Rect2(3340, 460, 210, 34), Rect2(3600, 530, 440, 90), Rect2(4080, 470, 230, 34),
		Rect2(4360, 520, 390, 90), Rect2(4780, 455, 210, 34), Rect2(5050, 510, 550, 90)
	]
	for i in range(platforms.size()):
		_add_platform(platforms[i], ERAS[min(int(platforms[i].position.x / SECTION_WIDTH), 6)]["accent"])
	# Solid blocks and broken machinery make the route require jumps and detours.
	_add_platform(Rect2(270, 420, 54, 80), Color("#49e4d1"), false)
	_add_platform(Rect2(950, 430, 62, 80), Color("#e6a64c"), false)
	_add_platform(Rect2(1660, 450, 58, 80), Color("#79b8e8"), false)
	_add_platform(Rect2(2240, 440, 60, 80), Color("#df8d58"), false)
	_add_platform(Rect2(2440, 450, 72, 70), Color("#df8d58"), false)
	_add_platform(Rect2(3050, 430, 58, 80), Color("#a4bd67"), false)
	_add_platform(Rect2(3780, 450, 68, 80), Color("#bd755e"), false)
	_add_platform(Rect2(4510, 440, 64, 80), Color("#d0a05d"), false)
	# Low ceiling slabs create narrow passages without blocking the whole route.
	_add_platform(Rect2(650, 300, 140, 28), Color("#49e4d1"), false)
	_add_platform(Rect2(1310, 320, 120, 28), Color("#e6a64c"), false)
	_add_platform(Rect2(2740, 290, 130, 28), Color("#79b8e8"), false)
	_add_platform(Rect2(3890, 310, 150, 28), Color("#a4bd67"), false)
	_add_platform(Rect2(4860, 290, 130, 28), Color("#d0a05d"), false)
	_add_spikes(1090, 510, 3, Color("#ff667e"))
	_add_spikes(2360, 520, 3, Color("#ff667e"))
	_add_spikes(3180, 510, 4, Color("#ff667e"))
	_add_spikes(4610, 520, 3, Color("#ff667e"))
	_add_platform(Rect2(0, MAP_BOTTOM, MAP_WIDTH, 100), Color("#263344"), false)

func _add_platform(rect: Rect2, accent: Color, walkable: bool = true) -> void:
	var body := StaticBody2D.new()
	body.position = rect.position + rect.size * 0.5
	body.collision_layer = 1
	body.collision_mask = 1
	var shape := CollisionShape2D.new()
	var box := RectangleShape2D.new()
	box.size = rect.size
	shape.shape = box
	body.add_child(shape)
	add_child(body)
	var face := Polygon2D.new()
	face.polygon = PackedVector2Array([Vector2(-rect.size.x/2, -rect.size.y/2), Vector2(rect.size.x/2, -rect.size.y/2), Vector2(rect.size.x/2, rect.size.y/2), Vector2(-rect.size.x/2, rect.size.y/2)])
	face.position = body.position
	face.color = Color("#202d3b") if walkable else Color("#33343c")
	face.z_index = -5
	add_child(face)
	var rim := Polygon2D.new()
	rim.polygon = PackedVector2Array([Vector2(-rect.size.x/2, -rect.size.y/2), Vector2(rect.size.x/2, -rect.size.y/2), Vector2(rect.size.x/2, -rect.size.y/2 + 5), Vector2(-rect.size.x/2, -rect.size.y/2 + 5)])
	rim.position = body.position
	rim.color = accent
	rim.z_index = -4
	add_child(rim)

func _add_spikes(x: float, floor_y: float, count: int, accent: Color) -> void:
	for i in range(count):
		var spike_x := x + float(i) * 24
		var points := PackedVector2Array([Vector2(spike_x, floor_y), Vector2(spike_x + 12, floor_y - 25), Vector2(spike_x + 24, floor_y)])
		var hazard := StaticBody2D.new()
		hazard.collision_layer = 1
		hazard.collision_mask = 1
		var collision := CollisionPolygon2D.new()
		collision.polygon = PackedVector2Array([Vector2(0, 0), Vector2(12, -25), Vector2(24, 0)])
		collision.position = Vector2(spike_x, floor_y)
		hazard.add_child(collision)
		add_child(hazard)
		var art := Polygon2D.new()
		art.polygon = points
		art.color = accent
		art.z_index = -3
		add_child(art)

func _build_landmarks() -> void:
	for i in range(7):
		var x := 130.0 + float(i) * SECTION_WIDTH
		# Ruined towers and old trees mark the changing eras in silhouette.
		for j in range(3):
			var width := 35.0 + float((i + j) % 3) * 18.0
			var height := 130.0 + float((i * 7 + j * 31) % 150)
			var tower := Polygon2D.new()
			tower.polygon = PackedVector2Array([Vector2(0, 0), Vector2(width, 0), Vector2(width - 8, -height), Vector2(8, -height)])
			tower.position = Vector2(x + float(j) * 155, 500)
			tower.color = Color("#111b28")
			tower.z_index = -40
			add_child(tower)
			var window := Polygon2D.new()
			window.polygon = PackedVector2Array([Vector2(-5, -12), Vector2(5, -12), Vector2(5, 12), Vector2(-5, 12)])
			window.position = tower.position + Vector2(width * 0.5, -height * 0.62)
			window.color = Color(ERAS[i]["accent"].r, ERAS[i]["accent"].g, ERAS[i]["accent"].b, 0.52)
			window.z_index = -39
			add_child(window)

func _place_existing_characters() -> void:
	var player := get_node_or_null("hráč") as CharacterBody2D
	if player:
		player.position = Vector2(80, 445)
		var camera := player.get_node_or_null("Camera2D") as Camera2D
		if camera:
			camera.position = Vector2.ZERO
			camera.limit_left = 0
			camera.limit_right = int(MAP_WIDTH)
			camera.limit_top = 0
			camera.limit_bottom = int(MAP_BOTTOM)
			camera.position_smoothing_enabled = true
			camera.position_smoothing_speed = 5.0
	# The project already contains its boss scene. Keep it and place it at the end of the route.
	var boss := get_node_or_null("CharacterBody2D") as CharacterBody2D
	if boss:
		boss.position = Vector2(MAP_WIDTH - 160.0, 445)

func get_map_width() -> float:
	return MAP_WIDTH
