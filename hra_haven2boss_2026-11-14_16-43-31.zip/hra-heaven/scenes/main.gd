extends Node2D

const PLAYER_SCENE: PackedScene = preload("res://scenes/hráč.tscn")
const BOSS_SCENE: PackedScene = preload("res://bossmain.tscn")
const ENEMY_SCRIPT: Script = preload("res://scripts/enemy.gd")
const TILE_TOP: Texture2D = preload("res://assets/mapy/industrial/1 Tiles/IndustrialTile_18.png")
const TILE_BODY: Array[Texture2D] = [
	preload("res://assets/mapy/industrial/1 Tiles/IndustrialTile_04.png"),
	preload("res://assets/mapy/industrial/1 Tiles/IndustrialTile_06.png"),
	preload("res://assets/mapy/industrial/1 Tiles/IndustrialTile_25.png"),
	preload("res://assets/mapy/industrial/1 Tiles/IndustrialTile_55.png"),
	preload("res://assets/mapy/industrial/1 Tiles/IndustrialTile_64.png"),
	preload("res://assets/mapy/industrial/1 Tiles/IndustrialTile_65.png"),
	preload("res://assets/mapy/industrial/1 Tiles/IndustrialTile_72.png"),
	preload("res://assets/mapy/industrial/1 Tiles/IndustrialTile_73.png")
]
const SAW_IDLE: Texture2D = preload("res://assets/mapy/lab/Traps/saw_idle.png")
const ATTACK_SHEET: Texture2D = preload("res://assets/hráč/Sprites/ATTACK 1.png")
const MAP_WIDTH := 5700.0
const MAP_BOTTOM := 920.0
const SECTION_WIDTH := 810.0
const ERAS := [
	{"title": "2420 · MĚSTO PO PÁDU", "accent": Color("#50e1d3"), "shade": Color("#12333d")},
	{"title": "2200 · OPUŠTĚNÁ TOVÁRNA", "accent": Color("#e6a354"), "shade": Color("#392a27")},
	{"title": "2000 · ZAMRZLÉ PŘEDMĚSTÍ", "accent": Color("#79bde9"), "shade": Color("#1e2c42")},
	{"title": "1800 · STARÉ MĚSTO", "accent": Color("#e28c69"), "shade": Color("#392a35")},
	{"title": "1500 · ZAPOMENUTÁ VESNICE", "accent": Color("#aecb72"), "shade": Color("#273729")},
	{"title": "1000 · TEMNÝ LES", "accent": Color("#d07a66"), "shade": Color("#202c27")},
	{"title": "500 · PRVNÍ OSADA", "accent": Color("#e3b66c"), "shade": Color("#382c27")}
]

var player: CharacterBody2D
var boss: CharacterBody2D
var _hud: CanvasLayer
var _health_bar: ProgressBar
var _health_text: Label
var _shards_text: Label
var _era_text: Label
var _boss_bar: ProgressBar
var _boss_box: VBoxContainer
var _status_text: Label
var _overlay: Control
var _collected_shards := 0
var _last_era := -1
var _won := false
var _paused := false
var _checkpoints: Array[Vector2] = [Vector2(80, 455), Vector2(1530, 438), Vector2(3040, 448), Vector2(4270, 455)]

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	_build_backdrop()
	_build_route()
	_build_landmarks()
	_spawn_player()
	_spawn_enemies()
	_spawn_boss()
	_build_hud()
	_build_pickups()
	_build_checkpoints()
	player.connect("health_changed", _on_health_changed)
	player.connect("died", _on_player_died)
	player.connect("shard_collected", _on_shard_collected)
	boss.connect("health_changed", _on_boss_health_changed)
	boss.connect("defeated", _on_boss_defeated)
	_on_health_changed(player.get("health"), player.get("max_health"))
	_on_shard_collected(0)
	_on_boss_health_changed(boss.get("health"), boss.get("max_health"))
	_era_text.text = String(ERAS[0]["title"])
	_show_status("Najdi cestu zpět časem. Boss čeká na konci.", 4.0)

func _process(_delta: float) -> void:
	if not is_instance_valid(player) or player.get("is_dead") == true or _won:
		return
	if player.global_position.y > 760.0:
		player.call("take_damage", 20, Vector2.ZERO)
		if not player.get("is_dead") == true:
			var checkpoint: Vector2 = player.get("checkpoint_position")
			player.global_position = checkpoint
			player.velocity = Vector2.ZERO
	var era_index := clampi(int(player.global_position.x / SECTION_WIDTH), 0, ERAS.size() - 1)
	if era_index != _last_era:
		_last_era = era_index
		_era_text.text = String(ERAS[era_index]["title"])
		if era_index > 0:
			_show_status("Čas se vrací…", 1.5)
	if is_instance_valid(boss):
		_boss_box.visible = player.global_position.distance_to(boss.global_position) < 1100.0

func _input(event: InputEvent) -> void:
	if event.is_action_pressed("ui_cancel"):
		if _overlay:
			if _paused:
				_resume_game()
			get_viewport().set_input_as_handled()
		elif not _won:
			_pause_game()
			get_viewport().set_input_as_handled()

func _build_backdrop() -> void:
	var sky := ColorRect.new()
	sky.color = Color("#090e1b")
	sky.position = Vector2(-200, -200)
	sky.size = Vector2(MAP_WIDTH + 400.0, MAP_BOTTOM + 500.0)
	sky.z_index = -110
	add_child(sky)
	var background_layers := [
		{"file": "Background.png", "y": -70.0, "factor": 0.12, "tint": Color(0.34, 0.43, 0.62, 0.68)},
		{"file": "2.png", "y": -35.0, "factor": 0.18, "tint": Color(0.42, 0.57, 0.72, 0.20)},
		{"file": "3.png", "y": 12.0, "factor": 0.28, "tint": Color(0.26, 0.42, 0.61, 0.54)},
		{"file": "4.png", "y": 54.0, "factor": 0.42, "tint": Color(0.39, 0.48, 0.68, 0.52)},
		{"file": "5.png", "y": 102.0, "factor": 0.58, "tint": Color(0.28, 0.38, 0.57, 0.60)}
	]
	for index in range(background_layers.size()):
		var config: Dictionary = background_layers[index]
		var parallax := Parallax2D.new()
		parallax.scroll_scale = Vector2(config["factor"], 0.0)
		parallax.repeat_size = Vector2(1152.0, 0.0)
		parallax.z_index = -100 + index * 5
		var skyline := Sprite2D.new()
		skyline.texture = load("res://assets/mapy/industrial/2 Background/" + String(config["file"]))
		skyline.centered = false
		skyline.position = Vector2(0, config["y"])
		skyline.scale = Vector2(2.0, 2.0)
		skyline.modulate = config["tint"]
		skyline.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
		parallax.add_child(skyline)
		add_child(parallax)
	for i in range(7):
		var x := float(i) * SECTION_WIDTH
		var era: Dictionary = ERAS[i]
		var shade: Color = era["shade"]
		var era_tint := Polygon2D.new()
		era_tint.polygon = PackedVector2Array([Vector2.ZERO, Vector2(SECTION_WIDTH, 0), Vector2(SECTION_WIDTH, 580), Vector2(0, 580)])
		era_tint.position = Vector2(x, 0)
		era_tint.color = Color(shade.r, shade.g, shade.b, 0.14)
		era_tint.z_index = -55
		add_child(era_tint)
		var title := Label.new()
		title.text = String(era["title"])
		title.position = Vector2(x + 46.0, 75.0)
		title.add_theme_font_size_override("font_size", 20)
		title.add_theme_color_override("font_color", era["accent"])
		title.add_theme_color_override("font_shadow_color", Color(0, 0, 0, 0.9))
		title.add_theme_constant_override("shadow_offset_x", 2)
		title.add_theme_constant_override("shadow_offset_y", 2)
		title.z_index = -15
		add_child(title)
		var marker := Polygon2D.new()
		marker.polygon = PackedVector2Array([Vector2.ZERO, Vector2(2, 0), Vector2(2, 460), Vector2(0, 460)])
		marker.position = Vector2(x, 135)
		marker.color = Color(era["accent"].r, era["accent"].g, era["accent"].b, 0.3)
		marker.z_index = -25
		add_child(marker)
	for i in range(85):
		var star := Polygon2D.new()
		var x := float((i * 379 + 83) % int(MAP_WIDTH))
		var y := float((i * 211 + 37) % 250)
		var radius := 1.0 + float(i % 2)
		star.polygon = PackedVector2Array([Vector2(-radius, -radius), Vector2(radius, -radius), Vector2(radius, radius), Vector2(-radius, radius)])
		star.position = Vector2(x, y)
		star.color = Color(0.58, 0.78, 0.92, 0.22 + float(i % 4) * 0.08)
		star.z_index = -50
		add_child(star)

func _build_route() -> void:
	var platforms: Array[Rect2] = [
		Rect2(0, 500, 620, 90), Rect2(680, 460, 190, 34), Rect2(910, 500, 400, 90),
		Rect2(1350, 455, 230, 34), Rect2(1620, 500, 470, 90), Rect2(2140, 455, 240, 34),
		Rect2(2420, 500, 460, 90), Rect2(2920, 465, 220, 34), Rect2(3180, 500, 430, 90),
		Rect2(3650, 455, 230, 34), Rect2(3920, 500, 440, 90), Rect2(4400, 460, 240, 34),
		Rect2(4680, 500, 400, 90), Rect2(5120, 460, 190, 34), Rect2(5340, 500, 360, 90)
	]
	for rect in platforms:
		var era_index := clampi(int(rect.position.x / SECTION_WIDTH), 0, ERAS.size() - 1)
		_add_platform(rect, ERAS[era_index]["accent"])
	# Jumpable rubble and broken machines provide cover and short detours.
	for obstacle in [Rect2(280, 420, 50, 80), Rect2(1040, 420, 58, 80), Rect2(1750, 420, 62, 80), Rect2(2580, 420, 56, 80), Rect2(3380, 420, 65, 80), Rect2(4100, 420, 60, 80), Rect2(4800, 420, 68, 80)]:
		_add_platform(obstacle, Color("#b76f68"), false)
	_add_spikes(1120.0, 455.0, 3)
	_add_spikes(2510.0, 455.0, 3)
	_add_spikes(3270.0, 455.0, 4)
	_add_spikes(4180.0, 455.0, 3)
	_add_spikes(4740.0, 455.0, 3)

func _add_platform(rect: Rect2, accent: Color, walkable: bool = true) -> void:
	var columns := maxi(1, roundi(rect.size.x / 32.0))
	var rows := maxi(2, ceili(rect.size.y / 32.0))
	var actual_size := Vector2(columns * 32.0, rows * 32.0)
	var body := StaticBody2D.new()
	body.position = Vector2(rect.position.x + actual_size.x / 2.0, rect.position.y + actual_size.y / 2.0)
	body.collision_layer = 1
	body.collision_mask = 1
	var collider := CollisionShape2D.new()
	var shape := RectangleShape2D.new()
	shape.size = actual_size
	collider.shape = shape
	body.add_child(collider)
	add_child(body)
	for row in range(rows):
		for column in range(columns):
			var tile := Sprite2D.new()
			if row == 0:
				tile.texture = TILE_TOP
				tile.modulate = accent.lerp(Color.WHITE, 0.76)
			else:
				var body_index := posmod(column * 3 + row * 5 + int(rect.position.x / 32.0), TILE_BODY.size())
				tile.texture = TILE_BODY[body_index]
				if not walkable:
					tile.modulate = Color(0.78, 0.76, 0.84)
			tile.position = Vector2(rect.position.x + column * 32.0 + 16.0, rect.position.y + row * 32.0 + 16.0)
			tile.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
			tile.z_index = -3
			add_child(tile)

func _add_spikes(x: float, floor_y: float, count: int) -> void:
	var frames := SpriteFrames.new()
	frames.add_animation("spin")
	frames.set_animation_speed("spin", 12.0)
	frames.set_animation_loop("spin", true)
	for frame_index in range(6):
		var atlas := AtlasTexture.new()
		atlas.atlas = SAW_IDLE
		atlas.region = Rect2(frame_index * 32.0, 0, 32, 32)
		frames.add_frame("spin", atlas)
	for index in range(count):
		var hazard := Area2D.new()
		hazard.position = Vector2(x + float(index) * 30.0 + 16.0, floor_y - 13.0)
		hazard.collision_layer = 0
		hazard.collision_mask = 1
		var collision := CollisionShape2D.new()
		var circle := CircleShape2D.new()
		circle.radius = 12.0
		collision.shape = circle
		hazard.add_child(collision)
		var saw := AnimatedSprite2D.new()
		saw.sprite_frames = frames
		saw.animation = "spin"
		saw.play()
		saw.scale = Vector2(1.15, 1.15)
		saw.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
		hazard.add_child(saw)
		hazard.body_entered.connect(_on_spike_touched)
		add_child(hazard)

func _build_landmarks() -> void:
	var props := [
		{"file": "Box1.png", "x": 365.0, "y": 484.0, "scale": 1.0},
		{"file": "Barrel1.png", "x": 525.0, "y": 487.0, "scale": 1.25},
		{"file": "Bench.png", "x": 765.0, "y": 425.0, "scale": 1.2},
		{"file": "Locker2.png", "x": 1230.0, "y": 478.0, "scale": 1.2},
		{"file": "Board1.png", "x": 1770.0, "y": 466.0, "scale": 1.35},
		{"file": "Barrel3.png", "x": 2040.0, "y": 487.0, "scale": 1.3},
		{"file": "Bench.png", "x": 2660.0, "y": 425.0, "scale": 1.25},
		{"file": "Screen1.png", "folder": "4 Animated objects", "x": 3430.0, "y": 475.0, "scale": 1.1},
		{"file": "Box5.png", "x": 4020.0, "y": 484.0, "scale": 1.1},
		{"file": "Barrel2.png", "x": 4310.0, "y": 487.0, "scale": 1.3},
		{"file": "Locker3.png", "x": 4835.0, "y": 478.0, "scale": 1.25},
		{"file": "Bench.png", "x": 5285.0, "y": 425.0, "scale": 1.2}
	]
	for prop in props:
		var sprite := Sprite2D.new()
		var folder := String(prop.get("folder", "3 Objects"))
		sprite.texture = load("res://assets/mapy/industrial/" + folder + "/" + String(prop["file"]))
		sprite.position = Vector2(prop["x"], prop["y"])
		sprite.scale = Vector2.ONE * float(prop["scale"])
		sprite.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
		sprite.z_index = -1
		add_child(sprite)
	for x in [210.0, 860.0, 1470.0, 2310.0, 3020.0, 3770.0, 4590.0, 5170.0]:
		var panel := Sprite2D.new()
		panel.texture = load("res://assets/mapy/lab/Decor/Individual_PNGs/decor_5.png")
		panel.position = Vector2(x, 280.0 + fposmod(x, 3.0) * 24.0)
		panel.scale = Vector2(1.3, 1.3)
		panel.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
		panel.z_index = -2
		add_child(panel)
	for checkpoint_index in range(1, _checkpoints.size()):
		var point: Vector2 = _checkpoints[checkpoint_index]
		var flag := Sprite2D.new()
		flag.texture = load("res://assets/mapy/industrial/3 Objects/Flag.png")
		flag.position = point + Vector2(0, -31)
		flag.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
		flag.z_index = -1
		add_child(flag)

func _spawn_player() -> void:
	player = PLAYER_SCENE.instantiate() as CharacterBody2D
	player.name = "hráč"
	player.position = Vector2(80, 440)
	player.process_mode = Node.PROCESS_MODE_PAUSABLE
	add_child(player)
	var camera := player.get_node_or_null("Camera2D") as Camera2D
	if not camera:
		camera = Camera2D.new()
		camera.name = "Camera2D"
		player.add_child(camera)
	camera.enabled = true
	camera.position = Vector2(0, -35)
	camera.zoom = Vector2(1.25, 1.25)
	camera.limit_left = 0
	camera.limit_right = int(MAP_WIDTH)
	camera.limit_top = -80
	camera.limit_bottom = 760
	camera.position_smoothing_enabled = true
	camera.position_smoothing_speed = 5.0
	player.set("checkpoint_position", Vector2(80, 455))

func _spawn_enemies() -> void:
	for spawn in [Vector2(760, 420), Vector2(1790, 420), Vector2(2780, 420), Vector2(3540, 420), Vector2(4520, 420), Vector2(4950, 420)]:
		var enemy := CharacterBody2D.new()
		enemy.set_script(ENEMY_SCRIPT)
		enemy.position = spawn
		enemy.process_mode = Node.PROCESS_MODE_PAUSABLE
		enemy.connect("defeated", _on_enemy_defeated)
		add_child(enemy)

func _spawn_boss() -> void:
	boss = BOSS_SCENE.instantiate() as CharacterBody2D
	boss.name = "ChronoBoss"
	boss.position = Vector2(5500, 438)
	boss.process_mode = Node.PROCESS_MODE_PAUSABLE
	add_child(boss)

func _build_pickups() -> void:
	for point in [Vector2(700, 365), Vector2(1440, 360), Vector2(2200, 360), Vector2(3000, 365), Vector2(3720, 360), Vector2(4480, 365), Vector2(5200, 360)]:
		var pickup := Area2D.new()
		pickup.position = point
		pickup.collision_layer = 0
		pickup.collision_mask = 1
		var shape_node := CollisionShape2D.new()
		var shape := CircleShape2D.new()
		shape.radius = 17.0
		shape_node.shape = shape
		pickup.add_child(shape_node)
		var crystal := Polygon2D.new()
		crystal.polygon = PackedVector2Array([Vector2(0, -18), Vector2(12, -5), Vector2(7, 16), Vector2(0, 22), Vector2(-7, 16), Vector2(-12, -5)])
		crystal.color = Color("#74efff")
		crystal.z_index = 3
		pickup.add_child(crystal)
		pickup.body_entered.connect(_on_shard_touched.bind(pickup))
		add_child(pickup)

func _build_checkpoints() -> void:
	for index in range(1, _checkpoints.size()):
		var point: Vector2 = _checkpoints[index]
		var x := point.x
		var flag := Polygon2D.new()
		flag.polygon = PackedVector2Array([Vector2(0, 0), Vector2(4, 0), Vector2(4, -82), Vector2(0, -82)])
		flag.position = point
		flag.color = Color("#d1b77b")
		flag.z_index = -1
		add_child(flag)
		var pennant := Polygon2D.new()
		pennant.polygon = PackedVector2Array([Vector2(4, -80), Vector2(42, -68), Vector2(4, -54)])
		pennant.position = flag.position
		pennant.color = Color("#72e6ce")
		pennant.z_index = -1
		add_child(pennant)
		var area := Area2D.new()
		area.position = point + Vector2(0, -30)
		area.collision_layer = 0
		area.collision_mask = 1
		var shape_node := CollisionShape2D.new()
		var shape := RectangleShape2D.new()
		shape.size = Vector2(72, 100)
		shape_node.shape = shape
		area.add_child(shape_node)
		area.body_entered.connect(_on_checkpoint_touched.bind(index))
		add_child(area)

func _build_hud() -> void:
	_hud = CanvasLayer.new()
	_hud.layer = 10
	_hud.process_mode = Node.PROCESS_MODE_ALWAYS
	add_child(_hud)
	var top := PanelContainer.new()
	top.position = Vector2(22, 20)
	top.custom_minimum_size = Vector2(345, 112)
	top.add_theme_stylebox_override("panel", _panel_style(Color(0.025, 0.045, 0.075, 0.88)))
	_hud.add_child(top)
	var column := VBoxContainer.new()
	column.add_theme_constant_override("separation", 6)
	top.add_child(column)
	var title := Label.new()
	title.text = "ČASOVÁ OSA  /  ZPÁTKY DOMŮ"
	title.add_theme_font_size_override("font_size", 16)
	title.add_theme_color_override("font_color", Color("#9eeef2"))
	column.add_child(title)
	_era_text = Label.new()
	_era_text.add_theme_font_size_override("font_size", 17)
	_era_text.add_theme_color_override("font_color", Color("#ffffff"))
	column.add_child(_era_text)
	var health_row := HBoxContainer.new()
	column.add_child(health_row)
	_health_bar = ProgressBar.new()
	_health_bar.custom_minimum_size = Vector2(220, 22)
	_health_bar.max_value = 100
	_health_bar.show_percentage = false
	_health_bar.add_theme_stylebox_override("background", _bar_style(Color("#271e2b")))
	_health_bar.add_theme_stylebox_override("fill", _bar_style(Color("#ef6571")))
	health_row.add_child(_health_bar)
	_health_text = Label.new()
	_health_text.add_theme_font_size_override("font_size", 14)
	health_row.add_child(_health_text)
	_shards_text = Label.new()
	_shards_text.text = "Časové krystaly  0 / 7"
	_shards_text.add_theme_color_override("font_color", Color("#8cecff"))
	column.add_child(_shards_text)
	var controls := Label.new()
	controls.text = "A/D nebo ←/→ pohyb   ·   Mezerník skok  ·  Shift běh\nJ sekni   ·   K časový pulz   ·   Esc pauza"
	controls.position = Vector2(22, 650)
	controls.add_theme_font_size_override("font_size", 15)
	controls.add_theme_color_override("font_color", Color(0.88, 0.93, 1.0, 0.9))
	controls.add_theme_color_override("font_shadow_color", Color(0, 0, 0, 0.9))
	controls.add_theme_constant_override("shadow_offset_x", 2)
	controls.add_theme_constant_override("shadow_offset_y", 2)
	_hud.add_child(controls)
	_boss_box = VBoxContainer.new()
	_boss_box.set_anchors_preset(Control.PRESET_CENTER_TOP)
	_boss_box.position = Vector2(-180, 18)
	_boss_box.custom_minimum_size = Vector2(360, 48)
	_boss_box.visible = false
	_hud.add_child(_boss_box)
	var boss_title := Label.new()
	boss_title.text = "STRÁŽCE ČASU"
	boss_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	boss_title.add_theme_color_override("font_color", Color("#ffb38e"))
	boss_title.add_theme_font_size_override("font_size", 16)
	_boss_box.add_child(boss_title)
	_boss_bar = ProgressBar.new()
	_boss_bar.custom_minimum_size = Vector2(360, 18)
	_boss_bar.max_value = 360
	_boss_bar.show_percentage = false
	_boss_bar.add_theme_stylebox_override("background", _bar_style(Color("#251b27")))
	_boss_bar.add_theme_stylebox_override("fill", _bar_style(Color("#ed705f")))
	_boss_box.add_child(_boss_bar)
	_status_text = Label.new()
	_status_text.set_anchors_preset(Control.PRESET_CENTER_TOP)
	_status_text.position = Vector2(-260, 80)
	_status_text.custom_minimum_size = Vector2(520, 34)
	_status_text.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_status_text.add_theme_font_size_override("font_size", 18)
	_status_text.add_theme_color_override("font_color", Color("#ffffff"))
	_status_text.add_theme_color_override("font_shadow_color", Color(0, 0, 0, 0.9))
	_status_text.add_theme_constant_override("shadow_offset_x", 2)
	_status_text.add_theme_constant_override("shadow_offset_y", 2)
	_hud.add_child(_status_text)

func _panel_style(color: Color) -> StyleBoxFlat:
	var style := StyleBoxFlat.new()
	style.bg_color = color
	style.border_color = Color(0.32, 0.75, 0.84, 0.55)
	style.set_border_width_all(1)
	style.set_corner_radius_all(10)
	style.content_margin_left = 16
	style.content_margin_right = 16
	style.content_margin_top = 12
	style.content_margin_bottom = 12
	return style

func _bar_style(color: Color) -> StyleBoxFlat:
	var style := StyleBoxFlat.new()
	style.bg_color = color
	style.set_corner_radius_all(7)
	return style

func _on_health_changed(current: int, maximum: int) -> void:
	if _health_bar:
		_health_bar.max_value = maximum
		_health_bar.value = current
		_health_text.text = "%d / %d" % [current, maximum]

func _on_shard_collected(total: int) -> void:
	_collected_shards = total
	if _shards_text:
		_shards_text.text = "Časové krystaly  %d / 7" % total

func _on_boss_health_changed(current: int, maximum: int) -> void:
	if _boss_bar:
		_boss_bar.max_value = maximum
		_boss_bar.value = current

func _on_enemy_defeated() -> void:
	_show_status("Nepřítel poražen", 1.0)

func _on_spike_touched(body: Node2D) -> void:
	if body == player and is_instance_valid(player):
		player.call("take_damage", 18, Vector2(0, -170))

func _on_shard_touched(body: Node2D, pickup: Area2D) -> void:
	if body == player and is_instance_valid(player):
		player.call("add_shard")
		pickup.queue_free()
		_show_status("Krystal času: +18 zdraví", 1.2)

func _on_checkpoint_touched(body: Node2D, checkpoint_index: int) -> void:
	if body != player or not is_instance_valid(player):
		return
	var point: Vector2 = _checkpoints[checkpoint_index]
	player.set("checkpoint_position", point)
	_show_status("Kontrolní bod uložen", 1.6)

func _on_player_died() -> void:
	_show_status("Čas tě vrací na poslední kontrolní bod…", 2.0)
	await get_tree().create_timer(0.85).timeout
	if is_instance_valid(player) and not _won:
		player.call("respawn")

func _on_boss_defeated() -> void:
	_won = true
	_show_overlay("STRÁŽCE ČASU PADL", "Prošel jsi sedmi epochami a změnil minulost.\nNasbírané krystaly: %d / 7" % _collected_shards, "Hrát znovu", _restart)

func _show_status(message: String, duration: float) -> void:
	if not _status_text:
		return
	_status_text.text = message
	_status_text.modulate.a = 1.0
	var tween := create_tween()
	tween.tween_interval(maxf(0.1, duration - 0.3))
	tween.tween_property(_status_text, "modulate:a", 0.0, 0.3)

func _pause_game() -> void:
	_paused = true
	get_tree().paused = true
	_show_overlay("PAUZA", "Pokračuj v cestě proti proudu času.", "Pokračovat", _resume_game)

func _resume_game() -> void:
	get_tree().paused = false
	_paused = false
	if is_instance_valid(_overlay):
		_overlay.queue_free()
	_overlay = null

func _show_overlay(title_text: String, description: String, button_text: String, action: Callable) -> void:
	if is_instance_valid(_overlay):
		_overlay.queue_free()
	_overlay = Control.new()
	_overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_overlay.process_mode = Node.PROCESS_MODE_ALWAYS
	_hud.add_child(_overlay)
	var shade := ColorRect.new()
	shade.color = Color(0.015, 0.025, 0.05, 0.78)
	shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_overlay.add_child(shade)
	var panel := PanelContainer.new()
	panel.set_anchors_preset(Control.PRESET_CENTER)
	panel.position = Vector2(-250, -130)
	panel.custom_minimum_size = Vector2(500, 260)
	panel.add_theme_stylebox_override("panel", _panel_style(Color(0.025, 0.05, 0.08, 0.98)))
	_overlay.add_child(panel)
	var column := VBoxContainer.new()
	column.alignment = BoxContainer.ALIGNMENT_CENTER
	column.add_theme_constant_override("separation", 16)
	panel.add_child(column)
	var heading := Label.new()
	heading.text = title_text
	heading.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	heading.add_theme_font_size_override("font_size", 27)
	heading.add_theme_color_override("font_color", Color("#a4f2ef"))
	column.add_child(heading)
	var body := Label.new()
	body.text = description
	body.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	body.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	body.add_theme_font_size_override("font_size", 17)
	body.add_theme_color_override("font_color", Color("#d7e0ee"))
	column.add_child(body)
	var button := Button.new()
	button.text = button_text
	button.custom_minimum_size = Vector2(180, 44)
	button.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	button.pressed.connect(action)
	column.add_child(button)

func _restart() -> void:
	get_tree().paused = false
	get_tree().reload_current_scene()
