extends CharacterBody2D

signal health_changed(current: int, maximum: int)
signal died
signal shard_collected(total: int)

@export var walk_speed: float = 230.0
@export var sprint_speed: float = 340.0
@export var jump_velocity: float = -430.0
@export var double_jump_velocity: float = -390.0
@export var max_health: int = 100

const ATTACK_SHEET: Texture2D = preload("res://assets/hráč/Sprites/ATTACK 1.png")

var health: int = 100
var facing: int = 1
var checkpoint_position: Vector2 = Vector2(80, 455)
var shards: int = 0
var is_dead: bool = false
var _jumps_left: int = 2
var _attack_cooldown: float = 0.0
var _attack_anim_time: float = 0.0
var _pulse_cooldown: float = 0.0
var _invulnerable_time: float = 0.0
var _pulse_flash: Polygon2D

@onready var animated_sprite: AnimatedSprite2D = $AnimatedSprite2D

func _ready() -> void:
	add_to_group("player")
	add_to_group("hrac")
	collision_layer = 1
	collision_mask = 1
	health = max_health
	_register_attack_animation()
	_pulse_flash = Polygon2D.new()
	_pulse_flash.polygon = _make_ring(118.0, 96.0, 24)
	_pulse_flash.color = Color(0.33, 0.91, 1.0, 0.28)
	_pulse_flash.z_index = 5
	_pulse_flash.visible = false
	add_child(_pulse_flash)
	health_changed.emit(health, max_health)

func _physics_process(delta: float) -> void:
	if is_dead:
		return
	_attack_cooldown = maxf(0.0, _attack_cooldown - delta)
	_attack_anim_time = maxf(0.0, _attack_anim_time - delta)
	_pulse_cooldown = maxf(0.0, _pulse_cooldown - delta)
	_invulnerable_time = maxf(0.0, _invulnerable_time - delta)
	if not is_on_floor():
		velocity.y += get_gravity().y * delta
	else:
		_jumps_left = 2

	var direction := Input.get_axis("levá", "pravá")
	if direction > 0.0:
		facing = 1
		animated_sprite.flip_h = false
	elif direction < 0.0:
		facing = -1
		animated_sprite.flip_h = true
	var speed := sprint_speed if Input.is_action_pressed("sprint") else walk_speed
	velocity.x = move_toward(velocity.x, direction * speed, 1500.0 * delta)

	if Input.is_action_just_pressed("skok") and _jumps_left > 0:
		velocity.y = jump_velocity if _jumps_left == 2 else double_jump_velocity
		_jumps_left -= 1
	if Input.is_key_pressed(KEY_J) and _attack_cooldown <= 0.0:
		_melee_attack()
	if Input.is_key_pressed(KEY_K) and _pulse_cooldown <= 0.0:
		_time_pulse()

	if _attack_anim_time > 0.0:
		if animated_sprite.animation != "attack":
			animated_sprite.play("attack")
	elif is_on_floor():
		if absf(direction) < 0.05:
			animated_sprite.play("idle")
		elif speed == sprint_speed:
			animated_sprite.play("run")
		else:
			animated_sprite.play("walk")
	else:
		animated_sprite.play("run")
	move_and_slide()


func _register_attack_animation() -> void:
	var frames := animated_sprite.sprite_frames
	if frames.has_animation("attack"):
		frames.remove_animation("attack")
	frames.add_animation("attack")
	frames.set_animation_speed("attack", 15.0)
	frames.set_animation_loop("attack", false)
	for frame_index in range(8):
		var atlas := AtlasTexture.new()
		atlas.atlas = ATTACK_SHEET
		atlas.region = Rect2(frame_index * 112.0, 0, 112, 96)
		frames.add_frame("attack", atlas)

func _melee_attack() -> void:
	_attack_cooldown = 0.48
	_attack_anim_time = 0.42
	animated_sprite.flip_h = facing < 0
	animated_sprite.play("attack")
	var query := PhysicsShapeQueryParameters2D.new()
	var box := RectangleShape2D.new()
	box.size = Vector2(92, 68)
	query.shape = box
	query.transform = Transform2D(0.0, global_position + Vector2(48.0 * facing, -27))
	query.collision_mask = 4
	query.collide_with_areas = false
	for hit in get_world_2d().direct_space_state.intersect_shape(query, 16):
		var target := hit.get("collider") as Node
		if target and target.is_in_group("enemies") and target.has_method("take_damage"):
			target.call("take_damage", 30, Vector2(facing * 270.0, -90.0))

func _time_pulse() -> void:
	_pulse_cooldown = 5.0
	_pulse_flash.visible = true
	_pulse_flash.scale = Vector2(0.5, 0.5)
	var tween := create_tween()
	tween.tween_property(_pulse_flash, "scale", Vector2.ONE, 0.23)
	tween.parallel().tween_property(_pulse_flash, "color:a", 0.0, 0.32)
	tween.finished.connect(func():
		if is_instance_valid(_pulse_flash):
			_pulse_flash.visible = false
			_pulse_flash.color = Color(0.33, 0.91, 1.0, 0.28)
	)
	var query := PhysicsShapeQueryParameters2D.new()
	var circle := CircleShape2D.new()
	circle.radius = 120.0
	query.shape = circle
	query.transform = Transform2D(0.0, global_position)
	query.collision_mask = 4
	for hit in get_world_2d().direct_space_state.intersect_shape(query, 24):
		var target := hit.get("collider") as Node
		if target and target.is_in_group("enemies") and target.has_method("take_damage"):
			var push: Vector2 = (target.global_position - global_position).normalized() * 420.0 + Vector2.UP * 120.0
			target.call("take_damage", 48, push)

func take_damage(amount: int, knockback: Vector2 = Vector2.ZERO) -> void:
	if is_dead or _invulnerable_time > 0.0:
		return
	health = maxi(0, health - amount)
	_invulnerable_time = 0.75
	velocity += knockback
	animated_sprite.modulate = Color(1.0, 0.38, 0.38)
	get_tree().create_timer(0.16).timeout.connect(func():
		if is_instance_valid(animated_sprite):
			animated_sprite.modulate = Color.WHITE
	)
	health_changed.emit(health, max_health)
	if health == 0:
		is_dead = true
		velocity = Vector2.ZERO
		died.emit()

func respawn() -> void:
	global_position = checkpoint_position
	velocity = Vector2.ZERO
	health = max_health
	is_dead = false
	_invulnerable_time = 1.4
	health_changed.emit(health, max_health)

func add_shard() -> void:
	shards += 1
	health = mini(max_health, health + 18)
	health_changed.emit(health, max_health)
	shard_collected.emit(shards)

func _make_ring(outer_radius: float, inner_radius: float, points: int) -> PackedVector2Array:
	var polygon := PackedVector2Array()
	for i in range(points + 1):
		var angle := TAU * float(i) / float(points)
		polygon.append(Vector2(cos(angle), sin(angle)) * outer_radius)
	for i in range(points, -1, -1):
		var angle := TAU * float(i) / float(points)
		polygon.append(Vector2(cos(angle), sin(angle)) * inner_radius)
	return polygon
