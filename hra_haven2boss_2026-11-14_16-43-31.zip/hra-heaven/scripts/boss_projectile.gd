extends Area2D

var velocity: Vector2 = Vector2.ZERO
var damage: int = 16
var _life: float = 4.0
var _spent: bool = false

func _ready() -> void:
	collision_layer = 8
	collision_mask = 1
	body_entered.connect(_on_body_entered)

func launch(direction: Vector2, damage_amount: int) -> void:
	velocity = direction.normalized() * 300.0
	damage = damage_amount

func _physics_process(delta: float) -> void:
	global_position += velocity * delta
	_life -= delta
	rotation += delta * 4.0
	if _life <= 0.0:
		queue_free()

func _on_body_entered(body: Node2D) -> void:
	if _spent:
		return
	if body.is_in_group("player") and body.has_method("take_damage"):
		_spent = true
		body.call("take_damage", damage, velocity.normalized() * 210.0 + Vector2.UP * 65.0)
		queue_free()
