extends CharacterBody2D

signal defeated

@export var max_health: int = 55
@export var move_speed: float = 82.0
@export var contact_damage: int = 10

var health: int = 55
var _target: CharacterBody2D
var _attack_timer: float = 0.0
var _jump_timer: float = 0.0
var _facing: int = -1

func _ready() -> void:
	add_to_group("enemies")
	collision_layer = 4
	collision_mask = 1
	health = max_health
	_build_look()
	var shape := CollisionShape2D.new()
	var capsule := CapsuleShape2D.new()
	capsule.radius = 12.0
	capsule.height = 36.0
	shape.shape = capsule
	shape.position.y = -18.0
	add_child(shape)
	_target = get_tree().get_first_node_in_group("player") as CharacterBody2D

func _physics_process(delta: float) -> void:
	_attack_timer = maxf(0.0, _attack_timer - delta)
	_jump_timer = maxf(0.0, _jump_timer - delta)
	if not is_on_floor():
		velocity.y += get_gravity().y * delta
	if _target and is_instance_valid(_target) and not _target.get("is_dead") == true:
		var offset := _target.global_position - global_position
		if absf(offset.x) < 390.0 and absf(offset.y) < 150.0:
			_facing = 1 if offset.x >= 0.0 else -1
			if absf(offset.x) > 36.0:
				velocity.x = move_toward(velocity.x, _facing * move_speed, 600.0 * delta)
			else:
				velocity.x = move_toward(velocity.x, 0.0, 900.0 * delta)
			if is_on_floor() and offset.y < -55.0 and _jump_timer <= 0.0:
				velocity.y = -330.0
				_jump_timer = 1.1
			if absf(offset.x) < 48.0 and absf(offset.y) < 52.0 and _attack_timer <= 0.0:
				_target.call("take_damage", contact_damage, Vector2(_facing * 190.0, -90.0))
				_attack_timer = 1.0
		else:
			velocity.x = move_toward(velocity.x, 0.0, 650.0 * delta)
	else:
		velocity.x = move_toward(velocity.x, 0.0, 650.0 * delta)
	move_and_slide()

func take_damage(amount: int, knockback: Vector2 = Vector2.ZERO) -> void:
	health = maxi(0, health - amount)
	velocity += knockback
	modulate = Color(1.0, 0.48, 0.4)
	get_tree().create_timer(0.12).timeout.connect(func():
		if is_instance_valid(self):
			modulate = Color.WHITE
	)
	if health <= 0:
		defeated.emit()
		queue_free()

func _build_look() -> void:
	var body := Polygon2D.new()
	body.polygon = PackedVector2Array([Vector2(-16, -2), Vector2(-13, -26), Vector2(-5, -36), Vector2(12, -32), Vector2(17, -17), Vector2(14, -2), Vector2(11, 0), Vector2(-12, 0)])
	body.color = Color("#b34f62")
	body.z_index = 1
	add_child(body)
	var armor := Polygon2D.new()
	armor.polygon = PackedVector2Array([Vector2(-12, -24), Vector2(11, -28), Vector2(15, -16), Vector2(-13, -14)])
	armor.color = Color("#e49367")
	armor.z_index = 2
	add_child(armor)
	var eye := Polygon2D.new()
	eye.polygon = PackedVector2Array([Vector2(-2, -25), Vector2(8, -24), Vector2(8, -20), Vector2(-2, -21)])
	eye.color = Color("#fff1bb")
	eye.z_index = 3
	add_child(eye)
