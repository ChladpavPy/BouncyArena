extends Area2D

@export var damage: int = 24
@export var knockback: Vector2 = Vector2(0, -260)

func _ready() -> void:
	collision_mask = 1
	body_entered.connect(_on_body_entered)

func _on_body_entered(body: Node2D) -> void:
	if body.is_in_group("player") and body.has_method("take_damage"):
		body.call("take_damage", damage, knockback)
