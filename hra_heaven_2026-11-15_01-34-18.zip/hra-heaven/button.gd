extends Button


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass

func _on_start_pressed():
	print("start pressed")
	get_tree().change_scene_to_file("res://scenes/UI_STATS.tscn")
	


func _on_pressed_BACK() -> void:
	get_tree().change_scene_to_file("res://scenes/Control.tscn")
	pass # Replace with function body.


	


func StartUiStats_on_pressed() -> void:
	get_tree().change_scene_to_file("res://scenes/main.tscn")


func settingsBack_on_pressed() -> void:
	get_tree().change_scene_to_file("res://scenes/Control.tscn")
	pass # Replace with function body.
