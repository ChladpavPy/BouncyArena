extends Node

var checkpoint_var: Vector2
var penize := 0
var mrtvý: bool = false
var die_var: Vector2
