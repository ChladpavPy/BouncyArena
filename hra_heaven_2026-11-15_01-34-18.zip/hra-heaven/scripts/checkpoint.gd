extends Area2D

@onready var hráč: CharacterBody2D = %hráč

func _on_body_entered(body):
	GameManager.checkpoint_var = hráč.global_position
	queue_free()
