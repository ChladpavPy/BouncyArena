extends Control

@onready var boss_hp: SpinBox = $HBoxContainer/VBoxContainer/boss_hp
@onready var boss_projectiles: SpinBox = $HBoxContainer/VBoxContainer/boss_projectiles
@onready var boss_fire_rate: SpinBox = $HBoxContainer/VBoxContainer/boss_fire_rate
@onready var boss_idle_rate: SpinBox = $HBoxContainer/VBoxContainer/boss_idle_rate
@onready var start_points: SpinBox = $HBoxContainer/VBoxContainer/start_points
@onready var player_hp: SpinBox = $HBoxContainer/VBoxContainer/player_hp


func _ready() -> void:
	boss_hp.value = GameManager.enemy_hp_start
	boss_projectiles.value = GameManager.enemy_projectiles
	boss_fire_rate.value = GameManager.fire_rate
	boss_idle_rate.value = GameManager.idle_rate
	start_points.value = GameManager.start_points
	player_hp.value = GameManager.player_hp
	
func _process(delta: float) -> void:
	GameManager.enemy_hp_start = boss_hp.value
	GameManager.enemy_projectiles = boss_projectiles.value
	GameManager.fire_rate = boss_fire_rate.value
	GameManager.idle_rate = boss_idle_rate.value
	GameManager.start_points = start_points.value
	GameManager.player_hp = player_hp.value
