extends Node

var checkpoint_var: Vector2
var penize := 0
var mrtvý: bool = false

#func _process(delta: float) -> void:
#	print(mrtvý)
