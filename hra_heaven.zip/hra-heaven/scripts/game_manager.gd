extends Node

var checkpoint_var: Vector2
var penize := 0
var mrtvý: bool = false
var enemy_hp: = 100
var player_hp: = 5
