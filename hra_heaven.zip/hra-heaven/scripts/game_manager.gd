extends Node

var start_points: int = 5
var enemy_projectiles: int = 8
var enemy_hp_start: float = 100
var player_start_hp: int = 5
var fire_rate: float = 1.0

var player_damage: float = 1.0
var player_defence: int = 1
var player_speed: float = 1.0
var stamina_multiplayer: float = 1.0
var enemy_stop := false
var mrtvý: bool = false
var number_of_deaths: int = 0
var player_hp: float = 5.0
var enemy_hp: float = 100
var checkpoint_var: Vector2
