extends Node

var checkpoint_var: Vector2
var penize := 0
var mrtvý: bool = false
var enemy_hp: float = 100
var player_hp: float = 5
var player_damage: float = 1
var player_defence: int = 1
var player_speed: float = 1
