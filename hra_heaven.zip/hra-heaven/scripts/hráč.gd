extends CharacterBody2D

const SPEED = 150.0
const JUMP_VELOCITY = -300.0
const OFFSET = 20

var double_jump: bool = true
var sprint: int = 1
var attack_bool: bool = false
var enemy_in: bool = false
var stamina = 1000
var attack_cost = 200

@onready var animated_sprite: AnimatedSprite2D = $AnimatedSprite2D
@onready var attack_area: Area2D = $AttackArea
@onready var player_hp_label: Label = $Camera2D/player_hp_label
@onready var stamina_bar: ProgressBar = %Stamina_bar
@onready var score_label: Label = $Camera2D/score_label


func _physics_process(delta: float) -> void:
	if GameManager.enemy_stop:
		return
	stamina += 50 * delta * GameManager.stamina_multiplayer
	if not is_on_floor():
		velocity += get_gravity() * delta
		if double_jump and Input.is_action_just_pressed("skok"):
			velocity.y = JUMP_VELOCITY * GameManager.player_speed
			double_jump = false
	
	if attack_bool == false:
		if Input.is_action_just_pressed("skok") and is_on_floor():
			velocity.y = JUMP_VELOCITY * GameManager.player_speed

		var direction := Input.get_axis("levá", "pravá")

		if direction > 0:
			animated_sprite.flip_h = false
			attack_area.position.x = abs(OFFSET)
		if direction < 0:
			animated_sprite.flip_h = true
			attack_area.position.x = -abs(OFFSET)
		if is_on_floor():
			double_jump = true
			if direction == 0:
				animated_sprite.play("idle")
			elif Input.is_action_pressed("sprint"):
				animated_sprite.play("run")
				sprint = 2
			else:
				animated_sprite.play("walk")
				sprint = 1
		if direction:
			velocity.x = direction * SPEED * sprint  * GameManager.player_speed
		else:
			velocity.x = move_toward(velocity.x, 0, SPEED)
	move_and_slide()

	if animated_sprite.is_playing() and animated_sprite.animation == "attack":
		attack_bool = true
	else:
		attack_bool = false

	if Input.is_action_just_pressed("attack") and attack_bool == false and stamina >= attack_cost / GameManager.stamina_multiplayer:
		animated_sprite.play("attack", GameManager.player_speed)
		attack_bool = true
		velocity.x = 0
		stamina -= attack_cost / GameManager.stamina_multiplayer
		if enemy_in:
			GameManager.enemy_hp -= GameManager.player_damage
			print(GameManager.enemy_hp)

	if GameManager.mrtvý:
		GameManager.player_hp -= 1 / (float(GameManager.player_defence) / 4)
		if GameManager.player_hp <= 0:
			animated_sprite.play("death")
			print(animated_sprite.animation)
			GameManager.enemy_stop = true
			await get_tree().create_timer(1.5).timeout
			global_position = GameManager.checkpoint_var
			GameManager.player_hp = 5
			$"../enemy".position = Vector2(0, 0)
			GameManager.number_of_deaths += 1
			get_tree().change_scene_to_file("res://scenes/UI_STATS.tscn")
		GameManager.mrtvý = false
	
	score_label.text = str("Number of Deaths: ", GameManager.number_of_deaths)
	player_hp_label.text = str("HP: ", "%.1f" % GameManager.player_hp)
	stamina_bar.value = stamina

func _on_attack_area_body_entered(body: Node2D) -> void:
	if body.name == "enemy":
		enemy_in = true

func _on_attack_area_body_exited(body: Node2D) -> void:
	if body.name == "enemy":
		enemy_in = false
		

func _on_timer_timeout() -> void:
	GameManager.extra_points += 1
