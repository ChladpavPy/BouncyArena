extends CharacterBody2D

const SPEED = 150.0
const JUMP_VELOCITY = -300.0
const OFFSET = 20

var double_jump: bool = true
var sprint: int = 1
var attack_bool: bool = false
var enemy_in: bool = false

@onready var animated_sprite: AnimatedSprite2D = $AnimatedSprite2D
@onready var attack_area: Area2D = $AttackArea
@onready var player_hp_label: Label = $Camera2D/player_hp_label

func _physics_process(delta: float) -> void:
	if not is_on_floor():
		velocity += get_gravity() * delta
		if double_jump and Input.is_action_just_pressed("skok"):
			velocity.y = JUMP_VELOCITY
			double_jump = false
	
	if attack_bool == false:
		if Input.is_action_just_pressed("skok") and is_on_floor():
			velocity.y = JUMP_VELOCITY

		var direction := Input.get_axis("levá", "pravá")

		if direction > 0:
			animated_sprite.flip_h = false
			attack_area.position.x = abs(OFFSET)
		if direction < 0:
			animated_sprite.flip_h = true
			attack_area.position.x = -abs(OFFSET)
		if is_on_floor():
			double_jump = true
			if direction == 0:
				animated_sprite.play("idle")
			elif Input.is_action_pressed("sprint"):
				animated_sprite.play("run")
				sprint = 2
			else:
				animated_sprite.play("walk")
				sprint = 1
		if direction:
			velocity.x = direction * SPEED * sprint
		else:
			velocity.x = move_toward(velocity.x, 0, SPEED)
	move_and_slide()

	if animated_sprite.is_playing() and animated_sprite.animation == "attack":
		attack_bool = true
	else:
		attack_bool = false

	if Input.is_action_just_pressed("attack") and attack_bool == false:
		animated_sprite.play("attack")
		attack_bool = true
		velocity.x = 0
		if enemy_in:
			GameManager.enemy_hp -= GameManager.player_damage
			print(GameManager.enemy_hp)

	if GameManager.mrtvý:
		print("mrtvý")
		GameManager.player_hp -= 1
		if GameManager.player_hp <= 0:
			global_position = GameManager.checkpoint_var
			GameManager.player_hp = 5
		GameManager.mrtvý = false

	player_hp_label.text = str(GameManager.player_hp)

func _on_attack_area_body_entered(body: Node2D) -> void:
	if body.name == "enemy":
		enemy_in = true

func _on_attack_area_body_exited(body: Node2D) -> void:
	if body.name == "enemy":
		enemy_in = false
