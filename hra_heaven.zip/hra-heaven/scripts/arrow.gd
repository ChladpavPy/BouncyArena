extends Area2D

var spawnPos:Vector2
var spawnRot: float
var dir: float
var speed: int = 500

@onready var timer: Timer = $Timer
@onready var ray_cast: RayCast2D = $RayCast2D

func _on_timer_timeout() -> void:
	queue_free()

func _ready() -> void:
	global_position = spawnPos
	global_rotation = spawnRot
	
	monitoring = false
	call_deferred("set_monitoring", true)
	
func _physics_process(delta: float) -> void:
	position += Vector2(speed, 0).rotated(dir) * delta
	
	if ray_cast.is_colliding():
		var collider = ray_cast.get_collider()
		
		if collider and not collider.name in ["hráč", "enemy"]:
			var normal = ray_cast.get_collision_normal()
			
			var vel = Vector2(speed, 0).rotated(dir)
			vel = vel.bounce(normal)
			
			dir = vel.angle()
			global_rotation = dir
			
			position += normal * 3.0

func _on_body_entered(body) -> void:
	if body.name == "hráč":
		GameManager.mrtvý = true
	queue_free()
	
