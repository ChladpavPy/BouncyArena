extends Area2D

@onready var hráč: CharacterBody2D = %hráč

var already_collected = false

func _on_body_entered(body):
	if already_collected == false:
		already_collected = true
		GameManager.checkpoint_var = hráč.position
		queue_free()
