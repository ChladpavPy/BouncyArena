extends Control


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass


func _on_start_pressed() -> void:
	print("pressed start")
	get_tree().change_scene_to_file("res://scenes/UI_STATS.tscn")

	#get_tree().change_scene_to_file("res://scenes/main.tscn")
	pass # Replace with function body.


func _on_exit_2_pressed() -> void:
	print("pressed exit")
	get_tree().quit()
	pass # Replace with function body.
	


func _on_settings_3_pressed() -> void:
	print("pressed settings")
	get_tree().change_scene_to_file("res://scenes/settings.tscn")
	pass # Replace with function body.
