extends CharacterBody2D

@onready var hráč: CharacterBody2D = %hráč
@onready var timer: Timer = $Timer
@onready var main = get_tree().get_root().get_node("main")
@onready var projectile = load("res://scenes/arrow.tscn")
@onready var timer_2: Timer = $Timer2
@onready var animated_sprite: AnimatedSprite2D = $AnimatedSprite2D
@onready var boss_hp_label: Label = $boss_hp_label

@export var speed = 75
var move := true
var animation_bool := false
@export var projectiles := 8

func shoot():
	for i in range(projectiles):
		var instance = projectile.instantiate()
		var current_dir = i * (TAU / projectiles)
		instance.dir = current_dir
		var spawn_distance = 20.0
		var offset = Vector2(cos(current_dir), sin(current_dir)) * spawn_distance
		
		instance.spawnPos = global_position + offset
		instance.spawnRot = i * (TAU / projectiles)
		main.add_child.call_deferred(instance)

func _physics_process(delta: float) -> void:
	if GameManager.enemy_hp <= 0:
		animated_sprite.play("death")
		await get_tree().create_timer(0.75).timeout
		queue_free()
	if move:
		animation_bool = false
		animated_sprite.play("idle")
		var direction = (hráč.position - position).normalized()
		velocity = direction * speed
		
		if direction.x < 0:
			animated_sprite.flip_h = true
		else:
			animated_sprite.flip_h = false
			
		move_and_slide()
	elif animation_bool == false:
			animation_bool = true
			animated_sprite.play("nečinný")
			
	boss_hp_label.text = str(GameManager.enemy_hp)

func _on_timer_timeout() -> void:
	shoot()

func _on_timer_2_timeout() -> void:
	timer.stop()
	move = false
	await get_tree().create_timer(5.0).timeout
	timer.start()
	move = true
