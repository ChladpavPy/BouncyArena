extends CharacterBody2D

@onready var hráč: CharacterBody2D = %hráč
@onready var timer: Timer = $Timer
@onready var main = get_tree().get_root().get_node("main")
@onready var projectile = load("res://scenes/arrow.tscn")
@onready var timer_2: Timer = $Timer2
@onready var animated_sprite: AnimatedSprite2D = $AnimatedSprite2D
@onready var boss_hp_bar: ProgressBar = $boss_hp_bar
@onready var timer3: Timer = $Timer3

const speed = 60

var move := true
var animation_bool := false
var projectiles = GameManager.enemy_projectiles
var start: Vector2

func _ready() -> void:
	$NavigationAgent2D.target_position = hráč.global_position
	timer.wait_time = GameManager.fire_rate
	timer_2.wait_time = GameManager.idle_rate
	start = position
	timer.start(GameManager.fire_rate)
	timer_2.start(GameManager.idle_rate)
	boss_hp_bar.max_value = GameManager.enemy_hp_start
	GameManager.enemy_hp = GameManager.enemy_hp_start
	
func shoot():
	for i in range(projectiles):
		var instance = projectile.instantiate()
		var current_dir = i * (TAU / projectiles)
		instance.dir = current_dir
		var spawn_distance = 20.0
		var offset = Vector2(cos(current_dir), sin(current_dir)) * spawn_distance
		
		instance.spawnPos = global_position + offset
		instance.spawnRot = i * (TAU / projectiles)
		main.add_child.call_deferred(instance)

func _physics_process(delta: float) -> void:
	if GameManager.enemy_stop:
		move = false
		position = start
		timer.stop()
		return
	if GameManager.enemy_hp <= 0:
		animated_sprite.play("death")
		await get_tree().create_timer(0.75).timeout
		queue_free()
		
	if move:
		animation_bool = false
		
		# AKTUALIZACE CESTY: Každý fyzikální snímek (nebo stačí občas) pošleme bosse za hráčem
		if is_instance_valid(hráč):
			$NavigationAgent2D.target_position = hráč.global_position
		
		if not $NavigationAgent2D.is_target_reached():
			var next_path_pos = $NavigationAgent2D.get_next_path_position()
			var nav_point_direction = global_position.direction_to(next_path_pos)
			
			velocity = nav_point_direction * speed
			
			if nav_point_direction.x < 0:
				animated_sprite.flip_h = true
			elif nav_point_direction.x > 0:
				animated_sprite.flip_h = false
		else:
			velocity = Vector2.ZERO
			
		animated_sprite.play("idle")
		move_and_slide()
	elif animation_bool == false:
			animation_bool = true
			animated_sprite.play("nečinný")
	
	
	boss_hp_bar.value = GameManager.enemy_hp

func _on_timer_timeout() -> void:
	shoot()

func _on_timer_2_timeout() -> void:
	timer.stop()
	timer_2.stop()
	move = false
	await get_tree().create_timer(5.0).timeout
	timer.start()
	timer_2.start()
	move = true
