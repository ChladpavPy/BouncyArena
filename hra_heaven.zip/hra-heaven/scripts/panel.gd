extends Panel

const points: int = 5
var current_points = points + GameManager.number_of_deaths
@onready var strength: Label = $"../strength"
@onready var agility: Label = $"../agility"
@onready var defence: Label = $"../defence"
@onready var attack: Label = $"../attack"
@onready var stamina: Label = $"../stamina"
@onready var skillpoints: Label = $"../skillpoints"

var points_strength_current:int = 0
var points_agility_current:int = 0
var points_defence_current:int = 0
var points_attack_current:int = 0
var points_stamina_current:int = 0

func _ready() -> void:
	if skillpoints:
		skillpoints.text = str(current_points)

func _on_fajfkabutton_pressed() -> void:
	# Strength
	GameManager.player_hp += points_strength_current * 0.5
	GameManager.player_damage += points_strength_current * 0.1
	
	# Agility
	GameManager.player_speed += points_agility_current * 0.1
	
	# Defence
	GameManager.player_defence += points_defence_current
	
	# Attack
	GameManager.player_damage += points_attack_current * 0.5
	
	# Stamina
	GameManager.stamina_multiplayer += points_stamina_current * 0.1
	
	GameManager.enemy_stop = false
	get_tree().change_scene_to_file("res://scenes/main.tscn")
	pass # Replace with function body.

func _on_krizekbutton_2_pressed() -> void:
	get_tree().change_scene_to_file("res://scenes/Control.tscn")
	pass
	
	
func _check_points() -> void:
	if points_stamina_current > 0 :
		print("hh")

func _on_button_strength_minus_pressed() -> void:
	
	if points_strength_current >= 1:
		print("strength changed by - 1 point")
		points_strength_current = points_strength_current - 1
		var text: String = str(points_strength_current)
		strength.text = text
		
		current_points = current_points + 1
		skillpoints.text = str(current_points)
	
	


func _on_button_strength_plus_pressed() -> void:
	
	if current_points >= 1:
		print("strength changed by + 1 point")
		points_strength_current = points_strength_current + 1
		var text: String = str(points_strength_current)
		strength.text = text
			
		current_points = current_points - 1
		skillpoints.text = str(current_points)
		
	
	


func _on_button_agility_minus_pressed() -> void:
	if points_agility_current >= 1:
		print("agility changed by - 1 point")
		points_agility_current = points_agility_current - 1
		var text: String = str(points_agility_current)
		agility.text = text
		
		current_points = current_points + 1
		skillpoints.text = str(current_points)
	
func _on_button_agility_plus_pressed() -> void:
	if current_points >= 1:
		print("agility changed by + 1 point")
		points_agility_current = points_agility_current + 1
		var text: String = str(points_agility_current)
		agility.text = text
		
		current_points = current_points - 1
		skillpoints.text = str(current_points)


func _on_button_defence_minus_pressed() -> void:
	if points_defence_current >= 1:
		print("defence changed by - 1 point")
		points_defence_current = points_defence_current - 1
		var text: String = str(points_defence_current)
		defence.text = text
		current_points = current_points + 1
		skillpoints.text = str(current_points)

func _on_button_defence_plus_pressed() -> void:
	if current_points >= 1:
		print("defence changed by + 1 point")
		points_defence_current = points_defence_current + 1
		var text: String = str(points_defence_current)
		defence.text = text 
		current_points = current_points - 1
		skillpoints.text = str(current_points)

func _on_button_attack_minus_pressed() -> void:
	if points_attack_current >= 1:
		print("attack changed by - 1 point")
		points_attack_current = points_attack_current - 1
		var text: String = str(points_attack_current)
		attack.text = text 
		current_points = current_points + 1
		skillpoints.text = str(current_points)



func _on_button_attack_plus_pressed() -> void:
	if current_points >= 1:
		print("attack changed by + 1 point")
		points_attack_current = points_attack_current +1
		var text: String = str(points_attack_current)
		attack.text = text 
		current_points = current_points - 1
		skillpoints.text = str(current_points)


func _on_button_stamina_minus_pressed() -> void:
	if points_stamina_current >= 1:
		print("stamina changed by - 1 point")
		points_stamina_current = points_stamina_current - 1
		var text: String = str(points_stamina_current)
		stamina.text = text 
		
		current_points = current_points + 1
		skillpoints.text = str(current_points)


func _on_button_stamina_plus_pressed() -> void:
	if current_points >= 1:
		print("stamina changed by + 1 point")
		points_stamina_current = points_stamina_current + 1
		var text: String = str(points_stamina_current)
		stamina.text = text 
		
		current_points = current_points - 1
		skillpoints.text = str(current_points)
	


func _on_butto_defence_minus_pressed() -> void:
	if points_defence_current >= 1:
		print("defence changed by - 1 point")
		points_defence_current = points_defence_current - 1
		var text: String = str(points_defence_current)
		defence.text = text
		current_points = current_points + 1
		skillpoints.text = str(current_points)
	
